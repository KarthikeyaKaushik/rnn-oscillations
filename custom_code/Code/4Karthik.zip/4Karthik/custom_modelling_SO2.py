#!/usr/bin/env python
# coding: utf-8

# In[103]:

import os
import sys
import numpy as np
from keras import optimizers
from keras.models import Model, Sequential, load_model
from keras.layers import Input, Embedding, LSTM, Dense, concatenate
#from dictionaries import d_words_g
import matplotlib.pyplot as plt
from keras import backend as K

#linux:
base = '//data/workspaces/lacns/workspaces/lacns-sanoev/working_data/Experiments/Collaborations/Karthikeya/RNNoscillations/'
base = '//home/sanoev/bin/Exp/Collaborations/Karthikeya/RNNoscillations/'
sys.path.append(base + '/SO04_Figures/')
Kloc = base + 'SO02_Scripts'
os.chdir(Kloc)
import custom_modelling_SO2_sub as subfun
import ColorScheme as cs
cmaps = cs.CCcolormap()
bfi = cs.baseFigInfo()   

WITH_END = True

#%% make word2vecs
#subfun.make_word2vecs() # only has to be done once!

#%% run model
# Add none and ends to the word dictionary for the output
new_dict = np.load(base + '/SO03_MidData/dic_word2vec_ding_new.npy',allow_pickle=True)
new_dict.item()['NONE'] = np.eye(new_dict.item()['cute'].shape[0])[0]
new_dict.item()['ENDW'] = np.eye(new_dict.item()['cute'].shape[0])[1]
new_dict.item()['ENDS'] = np.eye(new_dict.item()['cute'].shape[0])[2]
VOCAB = len(new_dict.item().keys())

# get data for model
train_data_gen = subfun.participants_gen_with_end_SO(train_gen=True,repeat_words=False, withend = WITH_END)
test_data_gen = subfun.participants_gen_with_end_SO(train_gen=False,repeat_words=False, withend = WITH_END)

# check the size of the imput
next(train_data_gen)[0].shape
next(test_data_gen)[0].shape

model = Sequential()
model.add(LSTM(100,input_shape=(240,300),return_sequences=True,return_state=False,name='lstm'))
model.add(Dense(VOCAB, name='pred'))
nadam = optimizers.Nadam(lr=0.01, beta_1=0.9, beta_2=0.999, epsilon=1e-08,
                         schedule_decay=0.004)
model.compile(loss='mean_squared_error', optimizer=nadam)
print(model.summary())
model.fit_generator(generator=train_data_gen, steps_per_epoch=100, epochs=10,
                                         verbose=1)
if WITH_END:
    model.save(base + '/SO03_MidData/models/not_repeated_with_end_new')
else:
    model.save(base + '/SO03_MidData/models/not_repeated_without_end_new')

#%% load model and generate and save output    
import custom_modelling_SO2_sub as subfun
if WITH_END:
    model = load_model(base + '/SO03_MidData/models/not_repeated_with_end_new')
else:
    model = load_model(base + '/SO03_MidData/models/not_repeated_without_end_new')
    
PsenTypes = ['sen', 'wordlist','nongrammar', 'nounphrase', 'verbphrase', 'random']
#PsenTypes = ['sen', 'nongrammar']

for Stype in PsenTypes:    
    train_data_gen = subfun.participants_gen_with_end_SO(train_gen=False,repeat_words=False, withend = WITH_END, \
                                                         SenType = Stype)
    train_data = next(train_data_gen)[0]
    
    lstm_model = Model(inputs=model.input,outputs=model.get_layer('lstm').output)
    activations = lstm_model.predict_on_batch(train_data)
    
    if WITH_END:
        data_storage_path = base + '/SO03_MidData/Data/data-vals/' + Stype + '/'    
    else:
        data_storage_path = base + '/SO03_MidData/Data/data-vals-without-end/' + Stype + '/'
    try: 
        os.mkdir(data_storage_path)
    except:
        print('path probably exists')
    
    np.save(data_storage_path + 'activations.npy',activations)   
    np.save(data_storage_path + 'embedded_inputs.npy',train_data)

#%% plot for all types
mifoi = 0.5
mfoi = 6

axs = list()
fig = plt.figure(constrained_layout=True, figsize = (bfi.figsize.Col2,10))
gs = fig.add_gridspec(6,2) 

for it, Stype in enumerate(PsenTypes): 
    if WITH_END:
        data_storage_path = base + '/SO03_MidData/Data/data-vals/' + Stype + '/'    
    else:
        data_storage_path = base + '/SO03_MidData/Data/data-vals-without-end/' + Stype + '/'
    activations = np.load(data_storage_path + 'activations.npy')   
    train_data = np.load(data_storage_path + 'embedded_inputs.npy')
       
    # input
    ft, freqs = subfun.ffthan_wrap(train_data, avgHidden = False, evoked = False, sr = 20)
    inx = (freqs>mifoi)&(freqs<mfoi)
    
    axs.append(fig.add_subplot(gs[it,0]))   
    axs[-1].plot(freqs[inx],ft[inx]); axs[-1].set_title(Stype + ': input')
    
    # hidden layers
    ft, freqs = subfun.ffthan_wrap(activations, avgHidden = False, evoked = False, sr = 20)    
    axs.append(fig.add_subplot(gs[it,1]))    
    axs[-1].plot(freqs[inx],ft[inx]); axs[-1].set_title(Stype + ': activations')






