#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct  6 10:51:51 2020

@author: sanoev
"""
#%%
import gensim
import csv
import numpy as np
from random import shuffle
#from dictionaries import d_words_g
import matplotlib.pyplot as plt
import random

#linux:
base = '//data/workspaces/lacns/workspaces/lacns-sanoev/working_data/Experiments/Collaborations/Karthikeya/RNNoscillations/'
base = '//home/sanoev/bin/Exp/Collaborations/Karthikeya/RNNoscillations/'
Kloc = base + 'SO02_Scripts'

#%%
def make_word2vecs():   
    # Load Google's pre-trained Word2Vec model
    model = gensim.models.KeyedVectors.load_word2vec_format(
        base + '/SO03_MidData/GoogleNews-vectors-negative300.bin', 
        binary=True)
    
    # Load all Ding's words
    with open(base + '/SO03_MidData/Ding_Noun.csv', 'r') as f:
        nouns_ding = [row[0] for row in csv.reader(f)]
    
    with open(base + '/SO03_MidData/Ding_adjective.csv', 'r') as f:
        adjs_ding = [row[0] for row in csv.reader(f)]
    
    with open(base + '/SO03_MidData/Ding_verb.csv', 'r') as f:
        verbs_ding = [row[0] for row in csv.reader(f)]
    
    words_ding = nouns_ding + adjs_ding + verbs_ding
    
    # Get vector for every word and save
    word_vectors_ding = []
    for word in words_ding:
        vector = model[word]
        word_vectors_ding.append(vector)
    
    # Make dictionary
    dic_word2vec_ding = dict(zip(words_ding, word_vectors_ding))
    
    # Save as a numpy file
    np.save(base + '/SO03_MidData/dic_word2vec_ding_new.npy', dic_word2vec_ding)

#%%
def create_sentences(SenType = 'sen'):
    # possible sentypes: 
    # sen:          regular sentence
    # wordlist:     wordlists
    # nongrammar:   grammatically correct, nonsensical
    # nounphrase:   noun phrases
    # verbphrase:   verb phrases
    # random:       adjective noun verb noun random
    
    # Load dictionaries
    new_dict = np.load(base + '/SO03_MidData/dic_word2vec_ding_new.npy',allow_pickle=True)
    new_dict.item()['NONE'] = np.zeros(new_dict.item()['cute'].shape[0])
    new_dict.item()['ENDW'] = np.zeros(new_dict.item()['cute'].shape[0])
    new_dict.item()['ENDS'] = np.zeros(new_dict.item()['cute'].shape[0])

    N = 60
    adjectives = list(np.genfromtxt(base + '/SO03_MidData/Ding_adjective.csv',dtype=str))
    nouns = list(np.genfromtxt(base + '/SO03_MidData/Ding_Noun.csv',dtype=str))
    verbs = list(np.genfromtxt(base + '/SO03_MidData/Ding_verb.csv',dtype=str))
        
    if SenType == 'sen':
        # Load words as lists
        with open(base + '/SO03_MidData/Ding_grammatical.csv', 'r') as f:
            sentence_list = [row for row in csv.reader(f)]
            
    elif SenType == 'wordlist':
        all_words = new_dict.item().keys()
        sentence_list = [random.sample(all_words,4) for i in range(N)]
        
    elif SenType == 'nongrammar':   
        sentence_list = list()
        for i in range(N):
            w1,w2,w3,w4 = '','','',''
            while w1 not in new_dict.item().keys():
                w1 = random.sample(adjectives,1)[0]
            while w2 not in new_dict.item().keys():
                w2 = random.sample(nouns,1)[0]
            while w3 not in new_dict.item().keys():
                w3 = random.sample(verbs,1)[0]
            while w4 not in new_dict.item().keys():
                w4 = random.sample(nouns,1)[0]
            sentence_list.append([w1,w2,w3,w4])
            
    elif SenType == 'nounphrase':        
        sentence_list = list()
        for i in range(N):
            w1,w2,w3,w4 = '','','',''
            while w1 not in new_dict.item().keys():
                w1 = random.sample(adjectives,1)[0]
            while w2 not in new_dict.item().keys():
                w2 = random.sample(nouns,1)[0]
            while w3 not in new_dict.item().keys():
                w3 = random.sample(adjectives,1)[0]
            while w4 not in new_dict.item().keys():
                w4 = random.sample(nouns,1)[0]
            sentence_list.append([w1,w2,w3,w4])
            
    elif SenType == 'verbphrase':
        sentence_list = list()
        for i in range(N):
            w1,w2,w3,w4 = '','','',''
            while w1 not in new_dict.item().keys():
                w1 = random.sample(verbs,1)[0]
            while w2 not in new_dict.item().keys():
                w2 = random.sample(nouns,1)[0]
            while w3 not in new_dict.item().keys():
                w3 = random.sample(verbs,1)[0]
            while w4 not in new_dict.item().keys():
                w4 = random.sample(nouns,1)[0]
            sentence_list.append([w1,w2,w3,w4])
            
    elif SenType == 'random':
        sentence_list = list()
        for i in range(N):
            w1,w2,w3,w4 = '','','',''
            while w1 not in new_dict.item().keys():
                w1 = random.sample(verbs,1)[0]
            while w2 not in new_dict.item().keys():
                w2 = random.sample(nouns,1)[0]
            while w3 not in new_dict.item().keys():
                w3 = random.sample(nouns,1)[0]
            while w4 not in new_dict.item().keys():
                w4 = random.sample(adjectives,1)[0]
            sentence_list.append([w1,w2,w3,w4]
            )    
    return sentence_list, new_dict
    
#%%
def participants_gen_with_end_SO(repeat_words=True, train_gen=True, withend = True, SenType = 'sen'):
    """Generates batches of sentences corresponding to the grammatical condition
    of Ding et all (2016). The Input words correspond to Word2Vec representations
    from Frank & Yang (2018).
   
    Args:
        train_gen: if it is for training (True) or testing (False)
        withend: output has only word endings or also sentence endings.
        repeat_words: if True words in the input sentences are repeated 4 times,
            otherwise filled with 'NONE' 3 times.
        SenType: 
            # sen:          regular sentence
            # wordlist:     wordlists
            # nongrammar:   adjective noun verb noun > grammatically correct, random words
            # nounphrase:   noun phrases
            # verbphrase:   verb phrases
            # random:       verb noun noun adjective
        
        
    Returns:
        A tuple of inputs and labels for training.
    """

    # load the sentences
    sentence_list, new_dict = create_sentences(SenType)  
        
    if train_gen == True: # keep selection of sentences apart for testing/training
        sentence_list = sentence_list[0:-13]
        Ntrl = 20
    else:
        sentence_list = sentence_list[-13:]
        Ntrl = 10
    Nsen = len(sentence_list)   
    while True:      
        # Lists to store inputs and labels
        input_batch = []
        output_batch = []
        for ind,sent in enumerate(sentence_list):
            # Repeat words or fill with 'NONE'
            if repeat_words:
                # 50 ms sample time, 20 samples/second
                input_words = [sent[0], sent[0], sent[0], sent[0], sent[0],
                               sent[1], sent[1], sent[1], sent[1], sent[1],
                               sent[2], sent[2], sent[2], sent[2], sent[2],
                               sent[3], sent[3], sent[3], sent[3], sent[3]]                

            else:                
                input_words = ['NONE', sent[0], sent[0], sent[0], sent[0],
                               'NONE', sent[1], sent[1], sent[1], sent[1],
                               'NONE', sent[2], sent[2], sent[2], sent[2],
                               'NONE', sent[3], sent[3], sent[3], sent[3]]
                
                if withend:
                    output_words = [sent[0], sent[0], sent[0], sent[0], 'ENDW',
                                   sent[1], sent[1], sent[1], sent[1], 'ENDW',
                                   sent[2], sent[2], sent[2], sent[2], 'ENDW',
                                   sent[3], sent[3], sent[3], sent[3], 'ENDS']
                else:
                    output_words = [sent[0], sent[0], sent[0], sent[0], 'ENDW',
                                   sent[1], sent[1], sent[1], sent[1], 'ENDW',
                                   sent[2], sent[2], sent[2], sent[2], 'ENDW',
                                   sent[3], sent[3], sent[3], sent[3], 'ENDW']
                
                                    
            # Generate one-hot representation of words for output (the model takes as input the indices directly)
            input_vectors = [new_dict.item().get(word) for word in input_words]
            output_vectors = [np.eye(len(new_dict.item().keys()))[[*new_dict.item().keys()].index(word)] for word in output_words]
            # Append to batch lists
            input_batch.append(input_vectors)
            output_batch.append(output_vectors)
            
        # in the Ding et al., 2016 they had 12 repetitions of sentences per trial for a total of 22 trials (but we are going to up this)                       
        input_batchT = np.array(input_batch)        
        output_batchT = np.array(output_batch).astype(bool)        
        
        r = 13 #(then start at random lags)
        usedSenCom = np.zeros([Ntrl,r])+Nsen+1  
        input_batchFS = np.zeros([Ntrl,r*input_batchT.shape[1],input_batchT.shape[2]])
        output_batchFS = np.zeros([Ntrl,r*output_batchT.shape[1],output_batchT.shape[2]])
        for trl in range(Ntrl):                
            # check if doesn't exist
            check = False            
            while check==False:
                rp = np.random.permutation(Nsen)
                n = 0
                for it in range(r):
                    if rp[it] in usedSenCom[:,it]:                            
                        n = n + 1
                if n <= r:
                    check = True
            usedSenCom[trl,:] = rp[0:r] 
            for it in range(r):              
                input_batchFS[trl,it*20:it*20+20,:] = input_batchT[rp[it],:,:]   
                output_batchFS[trl,it*20:it*20+20,:] = output_batchT[rp[it],:,:]   
        # create all the lags:
        l = 19
        input_batchFS2 = np.zeros([Ntrl*l,240,input_batchT.shape[2]])
        output_batchFS2 = np.zeros([Ntrl*l,240,output_batchT.shape[2]]).astype(bool)
        #output_batch = np.zeros([Ntrl*l, 3])
        for lcnt in range(l):
            input_batchFS2[lcnt*Ntrl:Ntrl*lcnt+Ntrl,:,:] = input_batchFS[:,lcnt:-(l-lcnt)-1,:]
            output_batchFS2[lcnt*Ntrl:Ntrl*lcnt+Ntrl,:,:] = output_batchFS[:,lcnt:-(l-lcnt)-1,:]
                
        # split into train and test data generator
        rp = np.random.permutation(output_batchFS2.shape[0])
        yield input_batchFS2[rp,:,:],output_batchFS2[rp,:]
        
#%% do fft:
def ffthan(data, sr = 4): # last dimension is fft dim
    han = np.hanning(data.shape[-1]) 
    data_han = data*han
    zv = np.zeros(data_han.shape)    
    data_han_pad = np.concatenate((zv, data_han, zv), axis=-1)    
    ft = np.fft.fft(data_han_pad, axis=-1)
    freqs = np.fft.fftfreq(data_han_pad.shape[-1], 1/sr)
    #ft = ft[:,(freqs>0) & (freqs < maxfoi)]
    #freqsN = freqs[(freqs>0) & (freqs < maxfoi)]
    ft = abs(ft)**2
    return ft, freqs

def ffthan_wrap(activations, avgHidden = True, evoked = False, sr = 5):
    act = np.moveaxis(activations, [0,1,2], [0,2,1])
    if evoked == True:
        act = np.mean(act,axis=1)
    if avgHidden == True:
        act = np.mean(act,axis=0)
    ft, freqs = ffthan(act,sr)
    
    #ft, freqs = subfun.ffthan(act, 20)    
    if evoked == False and avgHidden == False:
        ft = np.mean(np.mean(ft, axis=1),axis=0)
    elif  evoked == False or avgHidden == False:
        ft = np.mean(ft, axis=0)
    return ft, freqs
